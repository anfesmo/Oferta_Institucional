function VerMas(idEntidad) {
	localStorage.setItem("id_seleccionada", idEntidad);
    document.location.href = "convocatorias_entidad.html";
}
	
